#!/bin/bash

# اسکریپت راه‌اندازی و ساخت برنامه اندروید
echo "🚀 شروع راه‌اندازی برنامه معاملات خودکار موبایل"

# بررسی نصب Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js نصب نیست. لطفاً Node.js را نصب کنید."
    exit 1
fi

# بررسی نصب React Native CLI
if ! command -v react-native &> /dev/null; then
    echo "📦 نصب React Native CLI..."
    npm install -g react-native-cli
fi

# بررسی نصب وابستگی‌های npm
if [ ! -d "node_modules" ]; then
    echo "📦 نصب وابستگی‌های npm..."
    npm install
fi

# ورود به پوشه android و تمیز کردن
echo "🧹 تمیز کردن پروژه Android..."
cd android
./gradlew clean
cd ..

# نصب Android Build Tools (اگر نصب نباشد)
echo "🔧 بررسی Android Build Tools..."

# ساخت APK
echo "🔨 شروع ساخت APK..."
cd android
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo "✅ APK با موفقیت ساخته شد!"
    echo "📱 مسیر APK: android/app/build/outputs/apk/release/app-release.apk"
    
    # کپی APK به پوشه اصلی
    cp app/build/outputs/apk/release/app-release.apk ../MobileTradingApp.apk
    echo "📋 APK کپی شد: MobileTradingApp.apk"
    
    echo ""
    echo "🎉 برنامه آماده نصب است!"
    echo "📱 برای نصب: adb install MobileTradingApp.apk"
    echo "📋 برای امضای APK: jarsigner -verify -verbose MobileTradingApp.apk"
    
else
    echo "❌ خطا در ساخت APK"
    echo "🔧 لطفاً مجوزهای Android SDK را بررسی کنید"
    exit 1
fi

echo "✨ راه‌اندازی کامل شد!"