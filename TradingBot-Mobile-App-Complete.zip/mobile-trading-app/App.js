import React, { useEffect } from 'react';
import {
  StatusBar,
  StyleSheet,
  SafeAreaView,
  Platform,
  Alert
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialIcons';

import DashboardScreen from './src/screens/DashboardScreen';
import ExchangesScreen from './src/screens/ExchangesScreen';
import AIScreen from './src/screens/AIScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import TradesScreen from './src/screens/TradesScreen';

const Tab = createBottomTabNavigator();

const App = () => {
  useEffect(() => {
    // بررسی مجوزها
    if (Platform.OS === 'android') {
      // درخواست مجوزهای لازم برای اندروید
    }
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar 
        barStyle="light-content" 
        backgroundColor="#1a1a1a" 
      />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;
              
              switch (route.name) {
                case 'Dashboard':
                  iconName = 'dashboard';
                  break;
                case 'Trades':
                  iconName = 'trending-up';
                  break;
                case 'Exchanges':
                  iconName = 'account-balance';
                  break;
                case 'AI':
                  iconName = 'psychology';
                  break;
                case 'Settings':
                  iconName = 'settings';
                  break;
                default:
                  iconName = 'circle';
              }
              
              return <Icon name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: '#4CAF50',
            tabBarInactiveTintColor: 'gray',
            tabBarStyle: {
              backgroundColor: '#1a1a1a',
              borderTopWidth: 1,
              borderTopColor: '#333',
              height: 60,
              paddingBottom: 8,
            },
            tabBarLabelStyle: {
              fontSize: 12,
              fontWeight: 'bold'
            },
            headerStyle: {
              backgroundColor: '#1a1a1a',
              elevation: 0,
              shadowOpacity: 0,
            },
            headerTitleStyle: {
              color: '#fff',
              fontWeight: 'bold',
              fontSize: 18
            },
            headerTintColor: '#fff'
          })}
        >
          <Tab.Screen 
            name="Dashboard" 
            component={DashboardScreen}
            options={{ title: 'داشبورد' }}
          />
          <Tab.Screen 
            name="Trades" 
            component={TradesScreen}
            options={{ title: 'معاملات' }}
          />
          <Tab.Screen 
            name="Exchanges" 
            component={ExchangesScreen}
            options={{ title: 'صرافی‌ها' }}
          />
          <Tab.Screen 
            name="AI" 
            component={AIScreen}
            options={{ title: 'هوش مصنوعی' }}
          />
          <Tab.Screen 
            name="Settings" 
            component={SettingsScreen}
            options={{ title: 'تنظیمات' }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000'
  },
});

export default App;