// سرویس صرافی‌ها
import axios from 'axios';

class ExchangeService {
  constructor() {
    this.exchanges = new Map();
    this.defaultExchanges = [
      // صرافی‌های بین‌المللی
      {
        id: 'binance',
        name: 'Binance',
        type: 'crypto',
        enabled: true,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'ADAUSDT', 'SOLUSDT'],
        base_url: 'https://api.binance.com',
        isIranian: false
      },
      {
        id: 'bybit',
        name: 'Bybit',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCUSDT', 'ETHUSDT', 'USDCUSDT'],
        base_url: 'https://api.bybit.com',
        isIranian: false
      },
      {
        id: 'fxcm',
        name: 'FXCM',
        type: 'forex',
        enabled: false,
        sandbox: true,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['EURUSD', 'GBPUSD', 'USDJPY'],
        base_url: 'https://api.fxcm.com',
        isIranian: false
      },
      
      // صرافی‌های ایرانی
      {
        id: 'wallex',
        name: 'Wallex',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCIRT', 'ETHIRT', 'USDTIRT', 'TRXIRT', 'ADAIRT', 'SOLIRT'],
        base_url: 'https://api.wallex.ir',
        isIranian: true,
        documentation: 'https://docs.wallex.ir'
      },
      {
        id: 'nobitex',
        name: 'Nobitex',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCIRT', 'ETHIRT', 'USDTIRT', 'TRXIRT', 'ADAIRT', 'LTCIRT'],
        base_url: 'https://api.nobitex.ir',
        isIranian: true,
        documentation: 'https://nobitex.ir/api-docs'
      },
      {
        id: 'ramzinex',
        name: 'Ramzinex',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCIRT', 'ETHIRT', 'USDTIRT', 'ADAIRT', 'SOLIRT'],
        base_url: 'https://ramzinex.com/api',
        isIranian: true,
        documentation: 'https://docs.ramzinex.com'
      },
      {
        id: 'exir',
        name: 'Ex.ir',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCIRT', 'ETHIRT', 'USDTIRT', 'TRXIRT'],
        base_url: 'https://api.ex.ir',
        isIranian: true,
        documentation: 'https://ex.ir/api-docs'
      },
      {
        id: 'bitpin',
        name: 'بیت‌پین',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCIRT', 'ETHIRT', 'USDTIRT', 'ADAIRT', 'SOLIRT', 'DOTIRT'],
        base_url: 'https://bitpin.ir/api/v1',
        isIranian: true,
        documentation: 'https://bitpin.ir/docs'
      },
      {
        id: 'pay98',
        name: 'Pay98',
        type: 'crypto',
        enabled: false,
        sandbox: false,
        api_key: '',
        api_secret: '',
        status: 'disconnected',
        pairs: ['BTCIRT', 'ETHIRT', 'USDTIRT', 'TRXIRT', 'LTCIRT'],
        base_url: 'https://api.pay98.ir',
        isIranian: true,
        documentation: 'https://docs.pay98.ir'
      }
    ];
  }

  // دریافت لیست صرافی‌ها
  async getExchanges(filter = 'all') {
    try {
      switch (filter) {
        case 'iranian':
          return this.defaultExchanges.filter(exchange => exchange.isIranian);
        case 'international':
          return this.defaultExchanges.filter(exchange => !exchange.isIranian);
        default:
          return this.defaultExchanges;
      }
    } catch (error) {
      console.error('خطا در دریافت لیست صرافی‌ها:', error);
      return [];
    }
  }

  // دریافت صرافی‌های ایرانی
  async getIranianExchanges() {
    return await this.getExchanges('iranian');
  }

  // دریافت صرافی‌های بین‌المللی
  async getInternationalExchanges() {
    return await this.getExchanges('international');
  }

  // تست اتصال صرافی
  async testConnection(exchangeId) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || !exchange.api_key || !exchange.api_secret) {
        return { success: false, message: 'اطلاعات API کامل نیست' };
      }

      // شبیه‌سازی تست اتصال
      const isValid = await this.simulateConnectionTest(exchange);
      
      return {
        success: isValid,
        message: isValid ? 'اتصال موفق' : 'خطا در اتصال'
      };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // شبیه‌سازی تست اتصال
  async simulateConnectionTest(exchange) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (exchange.isIranian) {
          // برای صرافی‌های ایرانی، احتمال موفقیت کمی پایین‌تر
          const success = Math.random() > 0.2;
          resolve(success);
        } else {
          // برای صرافی‌های بین‌المللی
          const success = Math.random() > 0.1;
          resolve(success);
        }
      }, 2000);
    });
  }

  // اتصال واقعی به صرافی‌های ایرانی
  async connectToIranianExchange(exchangeId, credentials) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || !exchange.isIranian) {
        throw new Error('صرافی معتبر نیست');
      }

      const response = await axios.post(`${exchange.base_url}/v1/auth/login`, {
        username: credentials.username,
        password: credentials.password,
        totp: credentials.totp || ''
      }, {
        timeout: 10000
      });

      if (response.status === 200 && response.data.success) {
        this.updateExchangeStatus(exchangeId, 'connected');
        return {
          success: true,
          message: 'اتصال موفق',
          token: response.data.auth.token
        };
      } else {
        throw new Error(response.data.message || 'خطای ناشناخته');
      }
    } catch (error) {
      console.error(`خطا در اتصال به ${exchangeId}:`, error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  // دریافت مارکت داده از صرافی ایرانی
  async getIranianMarketData(exchangeId, pair) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || exchange.status !== 'connected' || !exchange.isIranian) {
        throw new Error('صرافی ایرانی متصل نیست');
      }

      const response = await axios.get(`${exchange.base_url}/v1/market/price`, {
        params: { symbol: pair },
        timeout: 5000
      });

      return {
        pair,
        price: response.data.price,
        change24h: response.data.change,
        volume: response.data.volume,
        high24h: response.data.high,
        low24h: response.data.low,
        timestamp: Date.now(),
        exchange: exchange.name
      };
    } catch (error) {
      console.error('خطا در دریافت مارکت داده ایرانی:', error);
      return null;
    }
  }

  // ثبت سفارش در صرافی ایرانی
  async placeIranianOrder(exchangeId, order) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || exchange.status !== 'connected' || !exchange.isIranian) {
        throw new Error('صرافی ایرانی متصل نیست');
      }

      // پیش‌پردازش سفارش برای صرافی‌های ایرانی
      const iranianOrder = {
        symbol: order.symbol,
        side: order.side === 'buy' ? 'buy' : 'sell',
        type: order.type || 'market',
        amount: order.amount,
        price: order.price || undefined
      };

      const response = await axios.post(`${exchange.base_url}/v1/trade/order`, iranianOrder, {
        headers: {
          'Authorization': `Bearer ${exchange.api_token}`,
          'Content-Type': 'application/json'
        },
        timeout: 10000
      });

      if (response.status === 200 && response.data.success) {
        return {
          success: true,
          orderId: response.data.orderId,
          status: 'pending',
          message: 'سفارش با موفقیت ثبت شد'
        };
      } else {
        throw new Error(response.data.message || 'خطا در ثبت سفارش');
      }
    } catch (error) {
      console.error('خطا در ثبت سفارش ایرانی:', error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  // دریافت لیست مارکت‌های صرافی ایرانی
  async getIranianMarkets(exchangeId) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || !exchange.isIranian) {
        return [];
      }

      const response = await axios.get(`${exchange.base_url}/v1/market/symbols`, {
        timeout: 5000
      });

      return response.data.symbols || [];
    } catch (error) {
      console.error('خطا در دریافت مارکت‌ها:', error);
      return [];
    }
  }

  // دریافت قیمت جفت ارز
  async getPrice(exchangeId, pair) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || exchange.status !== 'connected') {
        throw new Error('صرافی متصل نیست');
      }

      // قیمت‌های شبیه‌سازی شده
      const prices = {
        // جفت ارزهای بین‌المللی
        'BTCUSDT': 43000 + Math.random() * 1000,
        'ETHUSDT': 2500 + Math.random() * 200,
        'BNBUSDT': 300 + Math.random() * 50,
        'ADAUSDT': 0.45 + Math.random() * 0.1,
        'SOLUSDT': 95 + Math.random() * 15,
        'USDCUSDT': 1.0 + Math.random() * 0.02,
        'EURUSD': 1.085 + Math.random() * 0.01,
        'GBPUSD': 1.265 + Math.random() * 0.01,
        'USDJPY': 148.5 + Math.random() * 2,
        
        // جفت ارزهای ایرانی (به تومان)
        'BTCIRT': 1500000000 + Math.random() * 50000000,
        'ETHIRT': 85000000 + Math.random() * 5000000,
        'USDTIRT': 50000000 + Math.random() * 500000,
        'TRXIRT': 3000 + Math.random() * 500,
        'ADAIRT': 16000 + Math.random() * 2000,
        'SOLIRT': 3400000 + Math.random() * 200000,
        'LTCIRT': 4500000 + Math.random() * 200000,
        'DOTIRT': 18000 + Math.random() * 2000
      };

      return {
        pair,
        price: prices[pair] || 0,
        timestamp: Date.now(),
        exchange: exchange.name,
        isIranian: exchange.isIranian || false,
        currency: exchange.isIranian ? 'IRT' : 'USDT'
      };
    } catch (error) {
      console.error('خطا در دریافت قیمت:', error);
      throw error;
    }
  }

  // اجرای معامله
  async placeOrder(exchangeId, order) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || exchange.status !== 'connected') {
        throw new Error('صرافی متصل نیست');
      }

      // شبیه‌سازی ثبت معامله
      return new Promise((resolve) => {
        setTimeout(() => {
          const orderId = `${exchangeId}_${Date.now()}`;
          resolve({
            success: true,
            orderId,
            status: 'pending',
            message: 'معامله با موفقیت ثبت شد'
          });
        }, 1000);
      });
    } catch (error) {
      console.error('خطا در ثبت معامله:', error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  // بستن معامله
  async closeOrder(exchangeId, orderId) {
    try {
      const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
      if (!exchange || exchange.status !== 'connected') {
        throw new Error('صرافی متصل نیست');
      }

      // شبیه‌سازی بستن معامله
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            success: true,
            orderId,
            status: 'closed',
            message: 'معامله با موفقیت بسته شد'
          });
        }, 500);
      });
    } catch (error) {
      console.error('خطا در بستن معامله:', error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  // دریافت لیست جفت ارزهای پشتیبانی شده
  getSupportedPairs(exchangeId) {
    const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
    return exchange ? exchange.pairs : [];
  }

  // به‌روزرسانی وضعیت صرافی
  updateExchangeStatus(exchangeId, status) {
    const exchange = this.defaultExchanges.find(e => e.id === exchangeId);
    if (exchange) {
      exchange.status = status;
      exchange.lastUpdated = Date.now();
    }
  }
}

export default new ExchangeService();