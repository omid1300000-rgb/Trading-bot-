// سرویس هوش مصنوعی
import axios from 'axios';

class AIService {
  constructor() {
    this.aiConfigs = new Map();
    this.defaultConfigs = [
      {
        id: 'openai',
        name: 'OpenAI GPT',
        type: 'openai',
        enabled: true,
        api_endpoint: 'https://api.openai.com/v1/chat/completions',
        api_key: '',
        model: 'gpt-4',
        status: 'disconnected',
        max_tokens: 1000,
        temperature: 0.7
      },
      {
        id: 'claude',
        name: 'Claude AI',
        type: 'claude',
        enabled: false,
        api_endpoint: 'https://api.anthropic.com/v1/messages',
        api_key: '',
        model: 'claude-3-sonnet',
        status: 'disconnected',
        max_tokens: 1000,
        temperature: 0.7
      },
      {
        id: 'custom',
        name: 'AI سفارشی',
        type: 'custom',
        enabled: false,
        api_endpoint: '',
        api_key: '',
        model: 'custom-model',
        status: 'disconnected',
        max_tokens: 1000,
        temperature: 0.7
      }
    ];
  }

  // دریافت لیست پیکربندی‌های AI
  async getAIConfigs() {
    try {
      return this.defaultConfigs;
    } catch (error) {
      console.error('خطا در دریافت تنظیمات AI:', error);
      return [];
    }
  }

  // تست اتصال AI
  async testConnection(aiId) {
    try {
      const ai = this.defaultConfigs.find(a => a.id === aiId);
      if (!ai || !ai.api_key || !ai.api_endpoint) {
        return { success: false, message: 'اطلاعات API کامل نیست' };
      }

      // تست اتصال واقعی
      const isValid = await this.performConnectionTest(ai);
      
      return {
        success: isValid,
        message: isValid ? 'اتصال موفق' : 'خطا در اتصال'
      };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // انجام تست اتصال
  async performConnectionTest(ai) {
    try {
      if (ai.type === 'custom') {
        // برای AI سفارشی، فقط چک کردن URL
        return ai.api_endpoint.startsWith('http');
      }

      // برای OpenAI
      if (ai.type === 'openai') {
        const response = await axios.get('https://api.openai.com/v1/models', {
          headers: {
            'Authorization': `Bearer ${ai.api_key}`
          },
          timeout: 5000
        });
        return response.status === 200;
      }

      // برای Claude
      if (ai.type === 'claude') {
        const response = await axios.post(ai.api_endpoint, {
          model: ai.model,
          max_tokens: 10,
          messages: [{ role: 'user', content: 'Hi' }]
        }, {
          headers: {
            'x-api-key': ai.api_key,
            'Content-Type': 'application/json'
          },
          timeout: 5000
        });
        return response.status === 200;
      }

      return false;
    } catch (error) {
      console.error('خطا در تست اتصال AI:', error);
      return false;
    }
  }

  // درخواست پیش‌بینی از AI
  async getPrediction(aiId, marketData) {
    try {
      const ai = this.defaultConfigs.find(a => a.id === aiId);
      if (!ai || !ai.enabled || ai.status !== 'connected') {
        throw new Error('AI در دسترس نیست');
      }

      // آماده کردن prompt
      const prompt = this.preparePrompt(marketData);

      // ارسال درخواست بر اساس نوع AI
      let response;
      if (ai.type === 'openai') {
        response = await this.callOpenAI(ai, prompt);
      } else if (ai.type === 'claude') {
        response = await this.callClaude(ai, prompt);
      } else {
        response = await this.callCustomAI(ai, prompt);
      }

      // پردازش پاسخ
      return this.processPredictionResponse(response);
    } catch (error) {
      console.error('خطا در دریافت پیش‌بینی:', error);
      return {
        success: false,
        message: error.message,
        prediction: null
      };
    }
  }

  // آماده کردن prompt
  preparePrompt(marketData) {
    const { symbol, currentPrice, rsi, macd, priceChange, volume } = marketData;
    
    return `
بر اساس داده‌های زیر، پیش‌بینی کنید:

جفت ارز: ${symbol}
قیمت فعلی: ${currentPrice}
تغییر قیمت (24h): ${priceChange}%
RSI: ${rsi}
MACD: ${macd}
حجم معاملات: ${volume}

لطفاً پاسخ را در قالب JSON ارائه دهید:
{
  "action": "buy/sell/hold",
  "confidence": 0.8,
  "entry_price": 1.0850,
  "stop_loss": 1.0820,
  "take_profit": 1.0900,
  "position_size": 1000,
  "reasoning": "توضیح دلیل"
}
    `;
  }

  // فراخوانی OpenAI
  async callOpenAI(ai, prompt) {
    const response = await axios.post(ai.api_endpoint, {
      model: ai.model,
      messages: [
        { role: 'system', content: 'شما یک مشاور مالی حرفه‌ای هستید.' },
        { role: 'user', content: prompt }
      ],
      max_tokens: ai.max_tokens,
      temperature: ai.temperature
    }, {
      headers: {
        'Authorization': `Bearer ${ai.api_key}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data.choices[0].message.content;
  }

  // فراخوانی Claude
  async callClaude(ai, prompt) {
    const response = await axios.post(ai.api_endpoint, {
      model: ai.model,
      max_tokens: ai.max_tokens,
      messages: [
        { role: 'user', content: prompt }
      ]
    }, {
      headers: {
        'x-api-key': ai.api_key,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      }
    });

    return response.data.content[0].text;
  }

  // فراخوانی AI سفارشی
  async callCustomAI(ai, prompt) {
    const response = await axios.post(ai.api_endpoint, {
      prompt: prompt,
      model: ai.model,
      max_tokens: ai.max_tokens
    }, {
      headers: {
        'Authorization': `Bearer ${ai.api_key}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data.response || response.data.result;
  }

  // پردازش پاسخ پیش‌بینی
  processPredictionResponse(responseText) {
    try {
      // استخراج JSON از پاسخ
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('پاسخ معتبر JSON نیست');
      }

      const prediction = JSON.parse(jsonMatch[0]);
      
      // اعتبارسنجی داده‌ها
      const validActions = ['buy', 'sell', 'hold'];
      if (!validActions.includes(prediction.action)) {
        prediction.action = 'hold';
      }

      return {
        success: true,
        prediction: {
          action: prediction.action,
          confidence: Math.max(0, Math.min(1, prediction.confidence || 0.5)),
          entry_price: prediction.entry_price || 0,
          stop_loss: prediction.stop_loss || 0,
          take_profit: prediction.take_profit || 0,
          position_size: prediction.position_size || 0,
          reasoning: prediction.reasoning || ''
        }
      };
    } catch (error) {
      return {
        success: false,
        message: 'خطا در پردازش پاسخ AI',
        prediction: null
      };
    }
  }

  // دریافت سیگنال از AI
  async getSignal(aiId, symbol) {
    try {
      // شبیه‌سازی دریافت داده‌های بازار
      const mockMarketData = {
        symbol,
        currentPrice: 1.085 + Math.random() * 0.01,
        rsi: 50 + Math.random() * 40,
        macd: Math.random() - 0.5,
        priceChange: (Math.random() - 0.5) * 4,
        volume: 1000000 + Math.random() * 500000
      };

      return await this.getPrediction(aiId, mockMarketData);
    } catch (error) {
      console.error('خطا در دریافت سیگنال:', error);
      return {
        success: false,
        message: error.message,
        prediction: null
      };
    }
  }

  // به‌روزرسانی وضعیت AI
  updateAIStatus(aiId, status) {
    const ai = this.defaultConfigs.find(a => a.id === aiId);
    if (ai) {
      ai.status = status;
      ai.lastUpdated = Date.now();
    }
  }
}

export default new AIService();