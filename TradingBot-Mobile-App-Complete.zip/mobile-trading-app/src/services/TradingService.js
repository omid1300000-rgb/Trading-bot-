// سرویس معاملات
import ExchangeService from './ExchangeService';
import AIService from './AIService';

class TradingService {
  constructor() {
    this.activeTrades = [];
    this.tradeHistory = [];
    this.isAutoTrading = false;
    this.settings = {
      riskPercentage: 2.0,
      maxPositions: 5,
      defaultPositionSize: 1000,
      stopLossPct: 1.0,
      takeProfitPct: 2.0,
      preferredMarkets: ['EURUSD', 'GBPUSD', 'BTCUSDT'],
      autoMode: false,
      selectedExchange: 'binance',
      selectedAI: 'openai'
    };
  }

  // شروع معاملات خودکار
  async startAutoTrading() {
    try {
      if (this.isAutoTrading) {
        return { success: false, message: 'معاملات خودکار در حال اجرا است' };
      }

      // بررسی اتصال صرافی و AI
      const exchangeStatus = await ExchangeService.testConnection(this.settings.selectedExchange);
      const aiStatus = await AIService.testConnection(this.settings.selectedAI);

      if (!exchangeStatus.success || !aiStatus.success) {
        return { 
          success: false, 
          message: 'صرافی یا AI متصل نیست' 
        };
      }

      this.isAutoTrading = true;
      
      // شروع اسکن بازار
      this.startMarketScanning();
      
      return { 
        success: true, 
        message: 'معاملات خودکار شروع شد' 
      };
    } catch (error) {
      console.error('خطا در شروع معاملات خودکار:', error);
      return { 
        success: false, 
        message: error.message 
      };
    }
  }

  // توقف معاملات خودکار
  stopAutoTrading() {
    this.isAutoTrading = false;
    return { 
      success: true, 
      message: 'معاملات خودکار متوقف شد' 
    };
  }

  // شروع اسکن بازار
  startMarketScanning() {
    if (!this.isAutoTrading) return;

    const scanInterval = setInterval(async () => {
      if (!this.isAutoTrading) {
        clearInterval(scanInterval);
        return;
      }

      try {
        await this.scanMarketForOpportunities();
      } catch (error) {
        console.error('خطا در اسکن بازار:', error);
      }
    }, 30000); // هر 30 ثانیه
  }

  // اسکن بازار برای فرصت‌ها
  async scanMarketForOpportunities() {
    for (const symbol of this.settings.preferredMarkets) {
      if (!this.isAutoTrading) break;
      
      try {
        const signal = await AIService.getSignal(this.settings.selectedAI, symbol);
        
        if (signal.success && signal.prediction) {
          const prediction = signal.prediction;
          
          // اگر پیش‌بینی قوی باشد و پوزیشن فعال نباشد
          if (prediction.confidence > 0.7 && !this.hasActivePosition(symbol)) {
            await this.executeTrade(signal);
          }
        }
      } catch (error) {
        console.error(`خطا در اسکن ${symbol}:`, error);
      }
    }
  }

  // بررسی وجود پوزیشن فعال
  hasActivePosition(symbol) {
    return this.activeTrades.some(trade => 
      trade.symbol === symbol && trade.status === 'open'
    );
  }

  // اجرای معامله
  async executeTrade(signal) {
    try {
      const { prediction } = signal;
      const symbol = this.settings.preferredMarkets[0]; // انتخاب نماد
      const currentPrice = await ExchangeService.getPrice(
        this.settings.selectedExchange, 
        symbol
      );

      const trade = {
        id: `trade_${Date.now()}`,
        symbol,
        action: prediction.action,
        entryPrice: currentPrice.price,
        quantity: this.calculatePositionSize(currentPrice.price),
        stopLoss: prediction.stop_loss,
        takeProfit: prediction.take_profit,
        confidence: prediction.confidence,
        reasoning: prediction.reasoning,
        status: 'open',
        openedAt: new Date().toISOString(),
        exchange: this.settings.selectedExchange,
        aiProvider: this.settings.selectedAI
      };

      // ثبت در صرافی
      const orderResult = await ExchangeService.placeOrder(
        this.settings.selectedExchange,
        {
          type: 'market',
          side: prediction.action === 'buy' ? 'buy' : 'sell',
          quantity: trade.quantity,
          symbol: symbol
        }
      );

      if (orderResult.success) {
        trade.orderId = orderResult.orderId;
        this.activeTrades.push(trade);
        
        return {
          success: true,
          trade,
          message: `معامله ${symbol} با موفقیت باز شد`
        };
      } else {
        return {
          success: false,
          message: orderResult.message
        };
      }
    } catch (error) {
      console.error('خطا در اجرای معامله:', error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  // محاسبه اندازه پوزیشن
  calculatePositionSize(currentPrice) {
    const accountBalance = 10000; // موجودی فرضی حساب
    const riskAmount = accountBalance * (this.settings.riskPercentage / 100);
    const riskPerUnit = currentPrice * (this.settings.stopLossPct / 100);
    
    return Math.floor(riskAmount / riskPerUnit);
  }

  // بستن معامله
  async closeTrade(tradeId, reason = 'manual') {
    try {
      const tradeIndex = this.activeTrades.findIndex(t => t.id === tradeId);
      if (tradeIndex === -1) {
        throw new Error('معامله یافت نشد');
      }

      const trade = this.activeTrades[tradeIndex];
      
      // بستن در صرافی
      const closeResult = await ExchangeService.closeOrder(
        trade.exchange,
        trade.orderId
      );

      if (closeResult.success) {
        trade.status = 'closed';
        trade.closedAt = new Date().toISOString();
        trade.closeReason = reason;

        // انتقال به تاریخچه
        this.tradeHistory.push(trade);
        this.activeTrades.splice(tradeIndex, 1);

        return {
          success: true,
          trade,
          message: 'معامله با موفقیت بسته شد'
        };
      } else {
        return {
          success: false,
          message: closeResult.message
        };
      }
    } catch (error) {
      console.error('خطا در بستن معامله:', error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  // بررسی توقف ضرر و سود
  async monitorActiveTrades() {
    for (const trade of this.activeTrades) {
      if (trade.status !== 'open') continue;

      try {
        const currentPrice = await ExchangeService.getPrice(
          trade.exchange,
          trade.symbol
        );

        const shouldClose = this.shouldCloseTrade(trade, currentPrice.price);
        
        if (shouldClose.shouldClose) {
          await this.closeTrade(trade.id, shouldClose.reason);
        }
      } catch (error) {
        console.error(`خطا در بررسی معامله ${trade.id}:`, error);
      }
    }
  }

  // بررسی شرایط بستن معامله
  shouldCloseTrade(trade, currentPrice) {
    const profitPercentage = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
    
    // بررسی توقف ضرر
    if (profitPercentage <= -trade.stopLoss) {
      return {
        shouldClose: true,
        reason: 'stop_loss'
      };
    }
    
    // بررسی برداشت سود
    if (profitPercentage >= trade.takeProfit) {
      return {
        shouldClose: true,
        reason: 'take_profit'
      };
    }
    
    return { shouldClose: false, reason: null };
  }

  // دریافت لیست معاملات فعال
  getActiveTrades() {
    return this.activeTrades;
  }

  // دریافت تاریخچه معاملات
  getTradeHistory() {
    return this.tradeHistory;
  }

  // دریافت آمار معاملات
  getTradingStats() {
    const totalTrades = this.tradeHistory.length;
    const winningTrades = this.tradeHistory.filter(trade => {
      // محاسبه سود/ضرر
      const profit = ((trade.exitPrice - trade.entryPrice) / trade.entryPrice) * 100;
      return profit > 0;
    }).length;
    
    const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
    
    return {
      totalTrades,
      winningTrades,
      losingTrades: totalTrades - winningTrades,
      winRate: Math.round(winRate * 100) / 100,
      activeTrades: this.activeTrades.length,
      autoTrading: this.isAutoTrading
    };
  }

  // به‌روزرسانی تنظیمات
  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    return { 
      success: true, 
      settings: this.settings 
    };
  }

  // دریافت تنظیمات
  getSettings() {
    return this.settings;
  }
}

export default new TradingService();