// صفحه مدیریت صرافی‌ها
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Modal,
  TextInput,
  Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ExchangeService from '../services/ExchangeService';

const { width } = Dimensions.get('window');

const ExchangesScreen = () => {
  const [exchanges, setExchanges] = useState([]);
  const [iranianExchanges, setIranianExchanges] = useState([]);
  const [internationalExchanges, setInternationalExchanges] = useState([]);
  const [selectedTab, setSelectedTab] = useState('all'); // 'all', 'iranian', 'international'
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedExchange, setSelectedExchange] = useState(null);
  const [credentials, setCredentials] = useState({
    api_key: '',
    api_secret: '',
    username: '',
    password: '',
    totp: ''
  });
  const [testing, setTesting] = useState({});

  useEffect(() => {
    loadExchanges();
  }, []);

  const loadExchanges = async () => {
    try {
      const allExchanges = await ExchangeService.getExchanges();
      const iranian = await ExchangeService.getIranianExchanges();
      const international = await ExchangeService.getInternationalExchanges();
      
      setExchanges(allExchanges);
      setIranianExchanges(iranian);
      setInternationalExchanges(international);
    } catch (error) {
      console.error('خطا در بارگذاری صرافی‌ها:', error);
    }
  };

  const handleConnect = async (exchange) => {
    try {
      if (exchange.isIranian) {
        Alert.prompt(
          'ورود به حساب',
          'لطفاً اطلاعات ورود خود را وارد کنید:',
          [
            {
              text: 'لغو',
              style: 'cancel'
            },
            {
              text: 'ورود',
              onPress: async (username, password) => {
                const result = await ExchangeService.connectToIranianExchange(exchange.id, {
                  username,
                  password,
                  totp: ''
                });
                
                if (result.success) {
                  Alert.alert('موفقیت', 'اتصال برقرار شد');
                  loadExchanges();
                } else {
                  Alert.alert('خطا', result.message);
                }
              }
            }
          ]
        );
      } else {
        // برای صرافی‌های بین‌المللی، تست API
        setModalVisible(true);
        setSelectedExchange(exchange);
      }
    } catch (error) {
      Alert.alert('خطا', 'خطا در اتصال به صرافی');
    }
  };

  const handleTestConnection = async (exchange) => {
    setTesting(prev => ({ ...prev, [exchange.id]: true }));
    
    try {
      const result = await ExchangeService.testConnection(exchange.id);
      
      if (result.success) {
        Alert.alert('موفقیت', 'اتصال برقرار شد');
        ExchangeService.updateExchangeStatus(exchange.id, 'connected');
      } else {
        Alert.alert('خطا', result.message);
      }
    } catch (error) {
      Alert.alert('خطا', 'خطا در تست اتصال');
    } finally {
      setTesting(prev => ({ ...prev, [exchange.id]: false }));
    }
    
    loadExchanges();
  };

  const handleSaveCredentials = async () => {
    if (!selectedExchange || !credentials.api_key || !credentials.api_secret) {
      Alert.alert('خطا', 'لطفاً تمام فیلدهای ضروری را پر کنید');
      return;
    }

    try {
      // ذخیره اطلاعات به صورت محلی
      Alert.alert('موفقیت', 'اطلاعات ذخیره شد');
      setModalVisible(false);
      setCredentials({
        api_key: '',
        api_secret: '',
        username: '',
        password: '',
        totp: ''
      });
      setSelectedExchange(null);
    } catch (error) {
      Alert.alert('خطا', 'خطا در ذخیره اطلاعات');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return '#4CAF50';
      case 'error': return '#F44336';
      default: return '#757575';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'connected': return 'متصل';
      case 'error': return 'خطا';
      default: return 'غیرمتصل';
    }
  };

  const renderExchangeCard = (exchange) => (
    <View key={exchange.id} style={styles.exchangeCard}>
      <View style={styles.exchangeHeader}>
        <View style={styles.exchangeInfo}>
          <Text style={styles.exchangeName}>
            {exchange.name}
            {exchange.isIranian && (
              <Text style={styles.iranianFlag}> 🇮🇷</Text>
            )}
          </Text>
          <Text style={styles.exchangeType}>
            {exchange.type === 'crypto' ? 'ارز دیجیتال' : 'فارکس'}
          </Text>
        </View>
        
        <View style={[styles.statusIndicator, { backgroundColor: getStatusColor(exchange.status) }]}>
          <Text style={styles.statusText}>
            {getStatusText(exchange.status)}
          </Text>
        </View>
      </View>

      <View style={styles.exchangePairs}>
        <Text style={styles.pairsTitle}>جفت ارزهای پشتیبانی شده:</Text>
        <View style={styles.pairsContainer}>
          {exchange.pairs.slice(0, 4).map(pair => (
            <View key={pair} style={styles.pairTag}>
              <Text style={styles.pairText}>{pair}</Text>
            </View>
          ))}
          {exchange.pairs.length > 4 && (
            <Text style={styles.morePairs}>+{exchange.pairs.length - 4} مورد دیگر</Text>
          )}
        </View>
      </View>

      <View style={styles.exchangeActions}>
        {exchange.status === 'connected' ? (
          <TouchableOpacity
            style={[styles.actionButton, styles.disconnectButton]}
            onPress={() => {
              ExchangeService.updateExchangeStatus(exchange.id, 'disconnected');
              loadExchanges();
            }}
          >
            <Icon name="link-off" size={16} color="#fff" />
            <Text style={styles.actionButtonText}>قطع اتصال</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handleConnect(exchange)}
            disabled={testing[exchange.id]}
          >
            <Icon name={exchange.isIranian ? 'login' : 'link'} size={16} color="#fff" />
            <Text style={styles.actionButtonText}>
              {testing[exchange.id] ? 'در حال اتصال...' : 'اتصال'}
            </Text>
          </TouchableOpacity>
        )}

        {exchange.status !== 'connected' && (
          <TouchableOpacity
            style={[styles.actionButton, styles.testButton]}
            onPress={() => handleTestConnection(exchange)}
            disabled={testing[exchange.id]}
          >
            <Icon name="wifi-tethering" size={16} color="#fff" />
            <Text style={styles.actionButtonText}>تست</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  const renderCredentialsModal = () => (
    <Modal
      visible={modalVisible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setModalVisible(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>
              تنظیمات API - {selectedExchange?.name}
            </Text>
            <TouchableOpacity onPress={() => setModalVisible(false)}>
              <Icon name="close" size={24} color="#fff" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalBody}>
            {selectedExchange?.isIranian ? (
              <>
                <TextInput
                  style={styles.input}
                  placeholder="نام کاربری"
                  placeholderTextColor="#757575"
                  value={credentials.username}
                  onChangeText={(text) => setCredentials(prev => ({ ...prev, username: text }))}
                />
                <TextInput
                  style={styles.input}
                  placeholder="رمز عبور"
                  placeholderTextColor="#757575"
                  value={credentials.password}
                  onChangeText={(text) => setCredentials(prev => ({ ...prev, password: text }))}
                  secureTextEntry
                />
                <TextInput
                  style={styles.input}
                  placeholder="کد 2FA (اختیاری)"
                  placeholderTextColor="#757575"
                  value={credentials.totp}
                  onChangeText={(text) => setCredentials(prev => ({ ...prev, totp: text }))}
                />
              </>
            ) : (
              <>
                <TextInput
                  style={styles.input}
                  placeholder="API Key"
                  placeholderTextColor="#757575"
                  value={credentials.api_key}
                  onChangeText={(text) => setCredentials(prev => ({ ...prev, api_key: text }))}
                />
                <TextInput
                  style={styles.input}
                  placeholder="API Secret"
                  placeholderTextColor="#757575"
                  value={credentials.api_secret}
                  onChangeText={(text) => setCredentials(prev => ({ ...prev, api_secret: text }))}
                  secureTextEntry
                />
              </>
            )}

            <TouchableOpacity style={styles.saveButton} onPress={handleSaveCredentials}>
              <Text style={styles.saveButtonText}>ذخیره</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  const renderTabContent = () => {
    let displayExchanges = [];
    
    switch (selectedTab) {
      case 'iranian':
        displayExchanges = iranianExchanges;
        break;
      case 'international':
        displayExchanges = internationalExchanges;
        break;
      default:
        displayExchanges = exchanges;
    }

    return displayExchanges.map(renderExchangeCard);
  };

  return (
    <View style={styles.container}>
      {/* هدر با تب‌ها */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'all' && styles.activeTab]}
          onPress={() => setSelectedTab('all')}
        >
          <Text style={[styles.tabText, selectedTab === 'all' && styles.activeTabText]}>
            همه ({exchanges.length})
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'iranian' && styles.activeTab]}
          onPress={() => setSelectedTab('iranian')}
        >
          <Text style={[styles.tabText, selectedTab === 'iranian' && styles.activeTabText]}>
            ایرانی ({iranianExchanges.length})
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'international' && styles.activeTab]}
          onPress={() => setSelectedTab('international')}
        >
          <Text style={[styles.tabText, selectedTab === 'international' && styles.activeTabText]}>
            بین‌المللی ({internationalExchanges.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* لیست صرافی‌ها */}
      <ScrollView style={styles.exchangesList}>
        {renderTabContent()}
      </ScrollView>

      {/* مودال تنظیمات */}
      {renderCredentialsModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    paddingTop: 10
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#1a1a1a',
    marginHorizontal: 16,
    borderRadius: 10,
    padding: 4,
    marginBottom: 16
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center'
  },
  activeTab: {
    backgroundColor: '#4CAF50'
  },
  tabText: {
    color: '#757575',
    fontWeight: 'bold',
    fontSize: 12
  },
  activeTabText: {
    color: '#fff'
  },
  exchangesList: {
    flex: 1,
    paddingHorizontal: 16
  },
  exchangeCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  exchangeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  exchangeInfo: {
    flex: 1
  },
  exchangeName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4
  },
  iranianFlag: {
    fontSize: 16
  },
  exchangeType: {
    fontSize: 14,
    color: '#757575'
  },
  statusIndicator: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold'
  },
  exchangePairs: {
    marginBottom: 16
  },
  pairsTitle: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 8
  },
  pairsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  pairTag: {
    backgroundColor: '#333',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginRight: 8,
    marginBottom: 6
  },
  pairText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold'
  },
  morePairs: {
    color: '#757575',
    fontSize: 12,
    marginLeft: 8
  },
  exchangeActions: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 4,
    justifyContent: 'center'
  },
  disconnectButton: {
    backgroundColor: '#F44336'
  },
  testButton: {
    backgroundColor: '#2196F3'
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
    marginLeft: 6
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    width: width - 32,
    maxHeight: '80%'
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333'
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff'
  },
  modalBody: {
    padding: 16
  },
  input: {
    backgroundColor: '#333',
    color: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    fontSize: 14
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    marginTop: 16
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  }
});

export default ExchangesScreen;