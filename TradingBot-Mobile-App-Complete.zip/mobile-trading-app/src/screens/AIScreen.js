// صفحه تنظیمات هوش مصنوعی
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Modal,
  TextInput,
  Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import AIService from '../services/AIService';

const { width } = Dimensions.get('window');

const AIScreen = () => {
  const [aiConfigs, setAIConfigs] = useState([]);
  const [selectedAI, setSelectedAI] = useState('openai');
  const [modalVisible, setModalVisible] = useState(false);
  const [testing, setTesting] = useState({});
  const [credentials, setCredentials] = useState({
    api_endpoint: '',
    api_key: '',
    model: '',
    max_tokens: 1000,
    temperature: 0.7
  });

  useEffect(() => {
    loadAIConfigs();
  }, []);

  const loadAIConfigs = async () => {
    try {
      const configs = await AIService.getAIConfigs();
      setAIConfigs(configs);
    } catch (error) {
      console.error('خطا در بارگذاری تنظیمات AI:', error);
    }
  };

  const handleTestConnection = async (aiId) => {
    setTesting(prev => ({ ...prev, [aiId]: true }));
    
    try {
      const result = await AIService.testConnection(aiId);
      
      if (result.success) {
        Alert.alert('موفقیت', 'اتصال موفق');
        AIService.updateAIStatus(aiId, 'connected');
      } else {
        Alert.alert('خطا', result.message);
        AIService.updateAIStatus(aiId, 'error');
      }
    } catch (error) {
      Alert.alert('خطا', 'خطا در تست اتصال');
    } finally {
      setTesting(prev => ({ ...prev, [aiId]: false }));
    }
    
    loadAIConfigs();
  };

  const handleSaveConfig = async (aiConfig) => {
    try {
      // ذخیره تنظیمات به صورت محلی
      Alert.alert('موفقیت', 'تنظیمات ذخیره شد');
      setModalVisible(false);
      setCredentials({
        api_endpoint: '',
        api_key: '',
        model: '',
        max_tokens: 1000,
        temperature: 0.7
      });
    } catch (error) {
      Alert.alert('خطا', 'خطا در ذخیره تنظیمات');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return '#4CAF50';
      case 'error': return '#F44336';
      default: return '#757575';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'connected': return 'متصل';
      case 'error': return 'خطا';
      default: return 'غیرفعال';
    }
  };

  const renderAICard = (ai) => (
    <View key={ai.id} style={styles.aiCard}>
      <View style={styles.aiHeader}>
        <View style={styles.aiInfo}>
          <Text style={styles.aiName}>
            {ai.name}
            {ai.enabled && (
              <Text style={styles.enabledBadge}> فعال</Text>
            )}
          </Text>
          <Text style={styles.aiType}>
            {ai.type === 'openai' ? 'OpenAI GPT' : 
             ai.type === 'claude' ? 'Claude AI' : 'AI سفارشی'}
          </Text>
        </View>
        
        <View style={styles.aiControls}>
          <Switch
            value={ai.enabled}
            onValueChange={(value) => {
              // تغییر وضعیت فعال/غیرفعال
              ai.enabled = value;
              setSelectedAI(value ? ai.id : 'openai');
              loadAIConfigs();
            }}
            trackColor={{ false: '#333', true: '#4CAF50' }}
            thumbColor={ai.enabled ? '#fff' : '#757575'}
          />
          
          <View style={[styles.statusIndicator, { backgroundColor: getStatusColor(ai.status) }]}>
            <Text style={styles.statusText}>
              {getStatusText(ai.status)}
            </Text>
          </View>
        </View>
      </View>

      {ai.enabled && (
        <View style={styles.aiDetails}>
          <Text style={styles.aiDetailText}>
            مدل: {ai.model}
          </Text>
          <Text style={styles.aiDetailText}>
            Token: {ai.max_tokens}
          </Text>
          <Text style={styles.aiDetailText}>
            دما: {ai.temperature}
          </Text>
        </View>
      )}

      <View style={styles.aiActions}>
        <TouchableOpacity
          style={[styles.actionButton, ai.enabled && styles.selectedButton]}
          onPress={() => setSelectedAI(ai.id)}
        >
          <Icon name={ai.enabled ? 'check-circle' : 'radio-button-unchecked'} size={16} color="#fff" />
          <Text style={styles.actionButtonText}>
            {ai.enabled ? 'انتخاب شده' : 'انتخاب'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => {
            setCredentials({
              api_endpoint: ai.api_endpoint,
              api_key: ai.api_key,
              model: ai.model,
              max_tokens: ai.max_tokens,
              temperature: ai.temperature
            });
            setModalVisible(true);
          }}
        >
          <Icon name="settings" size={16} color="#fff" />
          <Text style={styles.actionButtonText}>تنظیمات</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => handleTestConnection(ai.id)}
          disabled={testing[ai.id]}
        >
          <Icon name="wifi-tethering" size={16} color="#fff" />
          <Text style={styles.actionButtonText}>
            {testing[ai.id] ? 'تست...' : 'تست'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderConfigModal = () => (
    <Modal
      visible={modalVisible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setModalVisible(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>تنظیمات API</Text>
            <TouchableOpacity onPress={() => setModalVisible(false)}>
              <Icon name="close" size={24} color="#fff" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalBody}>
            <TextInput
              style={styles.input}
              placeholder="API Endpoint"
              placeholderTextColor="#757575"
              value={credentials.api_endpoint}
              onChangeText={(text) => setCredentials(prev => ({ ...prev, api_endpoint: text }))}
              autoCapitalize="none"
              keyboardType="url"
            />
            
            <TextInput
              style={styles.input}
              placeholder="API Key"
              placeholderTextColor="#757575"
              value={credentials.api_key}
              onChangeText={(text) => setCredentials(prev => ({ ...prev, api_key: text }))}
              autoCapitalize="none"
            />

            <TextInput
              style={styles.input}
              placeholder="مدل"
              placeholderTextColor="#757575"
              value={credentials.model}
              onChangeText={(text) => setCredentials(prev => ({ ...prev, model: text }))}
            />

            <TextInput
              style={styles.input}
              placeholder="Max Tokens"
              placeholderTextColor="#757575"
              value={credentials.max_tokens.toString()}
              onChangeText={(text) => setCredentials(prev => ({ ...prev, max_tokens: parseInt(text) || 1000 }))}
              keyboardType="numeric"
            />

            <TextInput
              style={styles.input}
              placeholder="Temperature (0.0 - 1.0)"
              placeholderTextColor="#757575"
              value={credentials.temperature.toString()}
              onChangeText={(text) => setCredentials(prev => ({ ...prev, temperature: parseFloat(text) || 0.7 }))}
              keyboardType="numeric"
            />

            <TouchableOpacity style={styles.saveButton} onPress={handleSaveConfig}>
              <Text style={styles.saveButtonText}>ذخیره</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  const renderPredictionTest = () => (
    <View style={styles.testSection}>
      <Text style={styles.testTitle}>تست پیش‌بینی</Text>
      <Text style={styles.testDescription}>
        برای تست سیگنال‌دهی AI، سیستم یک پیش‌بینی تست برای EURUSD انجام می‌دهد
      </Text>
      
      <TouchableOpacity 
        style={styles.testButton}
        onPress={async () => {
          try {
            const result = await AIService.getSignal(selectedAI, 'EURUSD');
            
            if (result.success) {
              Alert.alert(
                'نتیجه پیش‌بینی',
                `عمل: ${result.prediction.action}\nاعتماد: ${(result.prediction.confidence * 100).toFixed(0)}%\nقیمت ورود: ${result.prediction.entry_price}\nتوقف ضرر: ${result.prediction.stop_loss}\nبرداشت سود: ${result.prediction.take_profit}`
              );
            } else {
              Alert.alert('خطا', result.message);
            }
          } catch (error) {
            Alert.alert('خطا', 'خطا در انجام پیش‌بینی');
          }
        }}
      >
        <Icon name="psychology" size={20} color="#fff" />
        <Text style={styles.testButtonText}>شروع تست</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* اطلاعات AI انتخاب شده */}
        <View style={styles.selectedInfo}>
          <Text style={styles.selectedTitle}>AI انتخاب شده:</Text>
          <Text style={styles.selectedName}>
            {aiConfigs.find(ai => ai.id === selectedAI)?.name || 'OpenAI GPT'}
          </Text>
        </View>

        {/* لیست AI ها */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>مدل‌های هوش مصنوعی</Text>
          {aiConfigs.map(renderAICard)}
        </View>

        {/* تست پیش‌بینی */}
        {renderPredictionTest()}
      </ScrollView>

      {/* مودال تنظیمات */}
      {renderConfigModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    paddingTop: 10
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 16
  },
  selectedInfo: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16
  },
  selectedTitle: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 4
  },
  selectedName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50'
  },
  section: {
    marginBottom: 20
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 12
  },
  aiCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  aiHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  aiInfo: {
    flex: 1
  },
  aiName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4
  },
  enabledBadge: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: 'normal'
  },
  aiType: {
    fontSize: 14,
    color: '#757575'
  },
  aiControls: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  statusIndicator: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8
  },
  statusText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold'
  },
  aiDetails: {
    backgroundColor: '#333',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12
  },
  aiDetailText: {
    color: '#fff',
    fontSize: 14,
    marginBottom: 4
  },
  aiActions: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#333',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginHorizontal: 2
  },
  selectedButton: {
    backgroundColor: '#4CAF50'
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4
  },
  testSection: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20
  },
  testTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8
  },
  testDescription: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 16,
    lineHeight: 20
  },
  testButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24
  },
  testButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 8
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    width: width - 32,
    maxHeight: '80%'
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333'
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff'
  },
  modalBody: {
    padding: 16
  },
  input: {
    backgroundColor: '#333',
    color: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    fontSize: 14
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    marginTop: 16
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  }
});

export default AIScreen;