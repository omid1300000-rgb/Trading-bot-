// صفحه تنظیمات اصلی برنامه
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  TextInput,
  Alert,
  Modal,
  Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import TradingService from '../services/TradingService';

const { width } = Dimensions.get('window');

const SettingsScreen = () => {
  const [settings, setSettings] = useState({
    riskPercentage: 2.0,
    maxPositions: 5,
    defaultPositionSize: 1000,
    stopLossPct: 1.0,
    takeProfitPct: 2.0,
    preferredMarkets: ['EURUSD', 'BTCUSDT'],
    autoMode: false,
    notifications: true,
    soundEnabled: true,
    language: 'fa',
    darkMode: true
  });
  
  const [modalVisible, setModalVisible] = useState(false);
  const [editingField, setEditingField] = useState('');
  const [tempValue, setTempValue] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const savedSettings = TradingService.getSettings();
      setSettings(savedSettings);
    } catch (error) {
      console.error('خطا در بارگذاری تنظیمات:', error);
    }
  };

  const updateSetting = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
    
    // ذخیره در سرویس
    TradingService.updateSettings({ [key]: value });
  };

  const handleEditField = (field, currentValue) => {
    setEditingField(field);
    setTempValue(currentValue.toString());
    setModalVisible(true);
  };

  const saveFieldValue = () => {
    const value = parseFloat(tempValue) || tempValue;
    updateSetting(editingField, value);
    setModalVisible(false);
    setTempValue('');
    setEditingField('');
  };

  const renderSettingItem = (title, subtitle, value, onPress, type = 'default') => (
    <TouchableOpacity style={styles.settingItem} onPress={onPress}>
      <View style={styles.settingInfo}>
        <Text style={styles.settingTitle}>{title}</Text>
        {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
      </View>
      <View style={styles.settingValue}>
        {type === 'toggle' ? (
          <Switch
            value={value}
            onValueChange={(newValue) => updateSetting(editingField, newValue)}
            trackColor={{ false: '#333', true: '#4CAF50' }}
            thumbColor={value ? '#fff' : '#757575'}
          />
        ) : (
          <Text style={styles.settingValueText}>
            {typeof value === 'boolean' ? (value ? 'فعال' : 'غیرفعال') : value}
          </Text>
        )}
        <Icon name="keyboard-arrow-left" size={20} color="#757575" />
      </View>
    </TouchableOpacity>
  );

  const renderSection = (title, children) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );

  const renderEditModal = () => (
    <Modal
      visible={modalVisible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setModalVisible(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>ویرایش {editingField}</Text>
            <TouchableOpacity onPress={() => setModalVisible(false)}>
              <Icon name="close" size={24} color="#fff" />
            </TouchableOpacity>
          </View>

          <View style={styles.modalBody}>
            <TextInput
              style={styles.input}
              value={tempValue}
              onChangeText={setTempValue}
              keyboardType="numeric"
              placeholder="مقدار جدید را وارد کنید"
              placeholderTextColor="#757575"
            />

            <TouchableOpacity style={styles.saveButton} onPress={saveFieldValue}>
              <Text style={styles.saveButtonText}>ذخیره</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* تنظیمات معاملات */}
        {renderSection('تنظیمات معاملات', (
          <>
            {renderSettingItem(
              'درصد ریسک',
              'میزان ریسک به ازای هر معامله',
              `${settings.riskPercentage}%`,
              () => handleEditField('riskPercentage', settings.riskPercentage)
            )}
            
            {renderSettingItem(
              'حداکثر معاملات همزمان',
              'حداکثر تعداد پوزیشن‌های باز',
              settings.maxPositions,
              () => handleEditField('maxPositions', settings.maxPositions)
            )}

            {renderSettingItem(
              'حجم پیش‌فرض',
              'حجم پیش‌فرض هر معامله',
              `${settings.defaultPositionSize} USDT`,
              () => handleEditField('defaultPositionSize', settings.defaultPositionSize)
            )}

            {renderSettingItem(
              'توقف ضرر (%)',
              'درصد توقف ضرر',
              `${settings.stopLossPct}%`,
              () => handleEditField('stopLossPct', settings.stopLossPct)
            )}

            {renderSettingItem(
              'برداشت سود (%)',
              'درصد برداشت سود',
              `${settings.takeProfitPct}%`,
              () => handleEditField('takeProfitPct', settings.takeProfitPct)
            )}

            {renderSettingItem(
              'بازارهای ترجیحی',
              'بازارهایی که سیستم بررسی می‌کند',
              `${settings.preferredMarkets.length} بازار`,
              () => {/* منطق انتخاب بازار */}
            )}
          </>
        ))}

        {/* تنظیمات سیستم */}
        {renderSection('تنظیمات سیستم', (
          <>
            {renderSettingItem(
              'حالت خودکار',
              'فعال/غیرفعال کردن معاملات خودکار',
              settings.autoMode,
              () => updateSetting('autoMode', !settings.autoMode),
              'toggle'
            )}

            {renderSettingItem(
              'اعلان‌ها',
              'دریافت اعلان‌های برنامه',
              settings.notifications,
              () => updateSetting('notifications', !settings.notifications),
              'toggle'
            )}

            {renderSettingItem(
              'صدا',
              'صدای اعلان‌ها',
              settings.soundEnabled,
              () => updateSetting('soundEnabled', !settings.soundEnabled),
              'toggle'
            )}

            {renderSettingItem(
              'زبان برنامه',
              'زبان رابط کاربری',
              settings.language === 'fa' ? 'فارسی' : 'انگلیسی',
              () => {/* منطق تغییر زبان */}
            )}
          </>
        ))}

        {/* اطلاعات */}
        {renderSection('اطلاعات', (
          <View style={styles.infoSection}>
            <TouchableOpacity style={styles.infoItem}>
              <Icon name="info" size={20} color="#4CAF50" />
              <Text style={styles.infoText}>درباره برنامه</Text>
              <Icon name="keyboard-arrow-left" size={20} color="#757575" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.infoItem}>
              <Icon name="help" size={20} color="#4CAF50" />
              <Text style={styles.infoText}>راهنما</Text>
              <Icon name="keyboard-arrow-left" size={20} color="#757575" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.infoItem}>
              <Icon name="security" size={20} color="#4CAF50" />
              <Text style={styles.infoText}>حریم خصوصی</Text>
              <Icon name="keyboard-arrow-left" size={20} color="#757575" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.infoItem}>
              <Icon name="contact-support" size={20} color="#4CAF50" />
              <Text style={styles.infoText}>پشتیبانی</Text>
              <Icon name="keyboard-arrow-left" size={20} color="#757575" />
            </TouchableOpacity>
          </View>
        ))}

        {/* دکمه ریست */}
        <TouchableOpacity 
          style={styles.resetButton}
          onPress={() => Alert.alert(
            'ریست تنظیمات',
            'آیا مطمئن هستید که می‌خواهید تمام تنظیمات را به حالت اولیه برگردانید؟',
            [
              { text: 'لغو', style: 'cancel' },
              { 
                text: 'ریست', 
                style: 'destructive',
                onPress: () => {
                  // ریست به تنظیمات پیش‌فرض
                  setSettings({
                    riskPercentage: 2.0,
                    maxPositions: 5,
                    defaultPositionSize: 1000,
                    stopLossPct: 1.0,
                    takeProfitPct: 2.0,
                    preferredMarkets: ['EURUSD', 'BTCUSDT'],
                    autoMode: false,
                    notifications: true,
                    soundEnabled: true,
                    language: 'fa',
                    darkMode: true
                  });
                }
              }
            ]
          )}
        >
          <Icon name="restore" size={20} color="#fff" />
          <Text style={styles.resetButtonText}>ریست تنظیمات</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* مودال ویرایش */}
      {renderEditModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000'
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16
  },
  section: {
    marginBottom: 24
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 12,
    textAlign: 'right'
  },
  settingItem: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  settingInfo: {
    flex: 1
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right'
  },
  settingSubtitle: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
    textAlign: 'right'
  },
  settingValue: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  settingValueText: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: 'bold',
    marginRight: 8
  },
  infoSection: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    overflow: 'hidden'
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333'
  },
  infoItem:lastChild: {
    borderBottomWidth: 0
  },
  infoText: {
    flex: 1,
    fontSize: 16,
    color: '#fff',
    textAlign: 'right',
    marginRight: 12
  },
  resetButton: {
    backgroundColor: '#F44336',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
    marginTop: 16
  },
  resetButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    width: width - 32,
    maxHeight: '50%'
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333'
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff'
  },
  modalBody: {
    padding: 16
  },
  input: {
    backgroundColor: '#333',
    color: '#fff',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    textAlign: 'center'
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    marginTop: 16
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  }
});

export default SettingsScreen;