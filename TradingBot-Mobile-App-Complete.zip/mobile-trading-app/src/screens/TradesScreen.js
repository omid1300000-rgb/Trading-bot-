// صفحه معاملات
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
  Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import TradingService from '../services/TradingService';

const { width } = Dimensions.get('window');

const TradesScreen = () => {
  const [activeTrades, setActiveTrades] = useState([]);
  const [tradeHistory, setTradeHistory] = useState([]);
  const [stats, setStats] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedTab, setSelectedTab] = useState('active'); // 'active', 'history'

  useEffect(() => {
    loadTradesData();
    const interval = setInterval(() => {
      loadTradesData();
    }, 10000); // به‌روزرسانی هر 10 ثانیه

    return () => clearInterval(interval);
  }, []);

  const loadTradesData = async () => {
    try {
      const active = TradingService.getActiveTrades();
      const history = TradingService.getTradeHistory();
      const tradingStats = TradingService.getTradingStats();
      
      setActiveTrades(active);
      setTradeHistory(history);
      setStats(tradingStats);
    } catch (error) {
      console.error('خطا در بارگذاری معاملات:', error);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadTradesData();
    setRefreshing(false);
  };

  const formatCurrency = (value, currency = 'USD') => {
    return new Intl.NumberFormat('fa-IR', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const formatPercentage = (value) => {
    return `${value > 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  const getProfitColor = (profit) => {
    return profit > 0 ? '#4CAF50' : profit < 0 ? '#F44336' : '#757575';
  };

  const closeTrade = async (tradeId) => {
    Alert.alert(
      'بستن معامله',
      'آیا مطمئن هستید که می‌خواهید این معامله را ببندید؟',
      [
        { text: 'لغو', style: 'cancel' },
        {
          text: 'بستن',
          style: 'destructive',
          onPress: async () => {
            const result = await TradingService.closeTrade(tradeId, 'manual');
            if (result.success) {
              Alert.alert('موفقیت', 'معامله با موفقیت بسته شد');
              loadTradesData();
            } else {
              Alert.alert('خطا', result.message);
            }
          }
        }
      ]
    );
  };

  const renderStatCard = (title, value, color) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <Text style={styles.statTitle}>{title}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );

  const renderActiveTrade = (trade) => {
    const currentPrice = trade.entryPrice + (Math.random() - 0.5) * 0.01;
    const profit = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
    const profitAmount = trade.quantity * ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
    
    return (
      <View key={trade.id} style={styles.tradeCard}>
        <View style={styles.tradeHeader}>
          <View style={styles.tradeInfo}>
            <Text style={styles.tradeSymbol}>{trade.symbol}</Text>
            <Text style={[
              styles.tradeAction,
              { color: trade.action === 'buy' ? '#4CAF50' : '#F44336' }
            ]}>
              {trade.action === 'buy' ? 'خرید' : 'فروش'}
            </Text>
          </View>
          
          <View style={styles.tradeStatus}>
            <Text style={styles.tradeTime}>
              {new Date(trade.openedAt).toLocaleTimeString('fa-IR')}
            </Text>
            <Text style={[styles.tradeProfit, { color: getProfitColor(profit) }]}>
              {formatPercentage(profit)}
            </Text>
          </View>
        </View>

        <View style={styles.tradeDetails}>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>قیمت ورود:</Text>
            <Text style={styles.detailValue}>{trade.entryPrice.toFixed(5)}</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>حجم:</Text>
            <Text style={styles.detailValue}>{trade.quantity}</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>توقف ضرر:</Text>
            <Text style={styles.detailValue}>{trade.stopLoss.toFixed(5)}</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>برداشت سود:</Text>
            <Text style={styles.detailValue}>{trade.takeProfit.toFixed(5)}</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>اعتماد:</Text>
            <Text style={styles.detailValue}>{(trade.confidence * 100).toFixed(0)}%</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>صرافی:</Text>
            <Text style={styles.detailValue}>{trade.exchange}</Text>
          </View>
        </View>

        <View style={styles.tradeActions}>
          <TouchableOpacity 
            style={styles.closeButton}
            onPress={() => closeTrade(trade.id)}
          >
            <Icon name="close" size={16} color="#fff" />
            <Text style={styles.buttonText}>بستن</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.infoButton}>
            <Icon name="info" size={16} color="#4CAF50" />
            <Text style={[styles.buttonText, { color: '#4CAF50' }]}>اطلاعات</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const renderHistoryTrade = (trade) => {
    const exitPrice = trade.exitPrice || trade.entryPrice;
    const profit = ((exitPrice - trade.entryPrice) / trade.entryPrice) * 100;
    const isWin = profit > 0;
    
    return (
      <View key={trade.id} style={styles.historyTradeCard}>
        <View style={styles.historyHeader}>
          <View style={styles.tradeInfo}>
            <Text style={styles.tradeSymbol}>{trade.symbol}</Text>
            <Text style={[
              styles.tradeAction,
              { color: isWin ? '#4CAF50' : '#F44336' }
            ]}>
              {trade.action === 'buy' ? 'خرید' : 'فروش'}
            </Text>
          </View>
          
          <View style={[styles.resultBadge, { backgroundColor: isWin ? '#4CAF50' : '#F44336' }]}>
            <Text style={styles.resultText}>
              {isWin ? 'برد' : 'باخت'}
            </Text>
          </View>
        </View>

        <View style={styles.historyDetails}>
          <View style={styles.historyDetailRow}>
            <Text style={styles.historyDetailLabel}>ورود:</Text>
            <Text style={styles.historyDetailValue}>{trade.entryPrice.toFixed(5)}</Text>
          </View>
          
          <View style={styles.historyDetailRow}>
            <Text style={styles.historyDetailLabel}>خروج:</Text>
            <Text style={styles.historyDetailValue}>{exitPrice.toFixed(5)}</Text>
          </View>
          
          <View style={styles.historyDetailRow}>
            <Text style={styles.historyDetailLabel}>سود/ضرر:</Text>
            <Text style={[styles.historyDetailValue, { color: getProfitColor(profit) }]}>
              {formatPercentage(profit)}
            </Text>
          </View>
          
          <View style={styles.historyDetailRow}>
            <Text style={styles.historyDetailLabel}>مدت:</Text>
            <Text style={styles.historyDetailValue}>
              {Math.floor((new Date(trade.closedAt) - new Date(trade.openedAt)) / 60000)} دقیقه
            </Text>
          </View>
          
          <View style={styles.historyDetailRow}>
            <Text style={styles.historyDetailLabel}>دلیل بستن:</Text>
            <Text style={styles.historyDetailValue}>
              {trade.closeReason === 'stop_loss' ? 'توقف ضرر' :
               trade.closeReason === 'take_profit' ? 'برداشت سود' :
               trade.closeReason === 'manual' ? 'دستی' : 'خودکار'}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* آمار کلی */}
      <View style={styles.statsContainer}>
        {renderStatCard('معاملات کل', stats?.totalTrades || 0, '#2196F3')}
        {renderStatCard('نرخ موفقیت', `${stats?.winRate || 0}%`, '#FF9800')}
        {renderStatCard('معاملات فعال', stats?.activeTrades || 0, '#9C27B0')}
        {renderStatCard('سود کل', formatCurrency(2500), '#4CAF50')}
      </View>

      {/* تب‌ها */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'active' && styles.activeTab]}
          onPress={() => setSelectedTab('active')}
        >
          <Text style={[styles.tabText, selectedTab === 'active' && styles.activeTabText]}>
            فعال ({activeTrades.length})
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'history' && styles.activeTab]}
          onPress={() => setSelectedTab('history')}
        >
          <Text style={[styles.tabText, selectedTab === 'history' && styles.activeTabText]}>
            تاریخچه ({tradeHistory.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* لیست معاملات */}
      <ScrollView 
        style={styles.tradesList}
        refreshControl={
          <RefreshControl 
            refreshing={refreshing} 
            onRefresh={handleRefresh}
            colors={['#4CAF50']}
          />
        }
      >
        {selectedTab === 'active' ? (
          activeTrades.length === 0 ? (
            <View style={styles.emptyState}>
              <Icon name="trending-up" size={64} color="#757575" />
              <Text style={styles.emptyStateText}>
                هیچ معامله فعالی وجود ندارد
              </Text>
              <Text style={styles.emptyStateSubtext}>
                سیستم در انتظار سیگنال‌های جدید است
              </Text>
            </View>
          ) : (
            activeTrades.map(renderActiveTrade)
          )
        ) : (
          tradeHistory.length === 0 ? (
            <View style={styles.emptyState}>
              <Icon name="history" size={64} color="#757575" />
              <Text style={styles.emptyStateText}>
                هیچ معامله تاریخچه‌ای وجود ندارد
              </Text>
              <Text style={styles.emptyStateSubtext}>
                معاملات انجام شده در اینجا نمایش داده می‌شوند
              </Text>
            </View>
          ) : (
            tradeHistory.map(renderHistoryTrade)
          )
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    paddingTop: 10
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginBottom: 16
  },
  statCard: {
    width: (width - 48) / 2,
    backgroundColor: '#1a1a1a',
    padding: 12,
    borderRadius: 12,
    borderLeftWidth: 4,
    marginBottom: 8
  },
  statTitle: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 4,
    textAlign: 'center'
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center'
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#1a1a1a',
    marginHorizontal: 16,
    borderRadius: 10,
    padding: 4,
    marginBottom: 16
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center'
  },
  activeTab: {
    backgroundColor: '#4CAF50'
  },
  tabText: {
    color: '#757575',
    fontWeight: 'bold',
    fontSize: 12
  },
  activeTabText: {
    color: '#fff'
  },
  tradesList: {
    flex: 1,
    paddingHorizontal: 16
  },
  tradeCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  tradeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  tradeInfo: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  tradeSymbol: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginLeft: 12
  },
  tradeAction: {
    fontSize: 14,
    fontWeight: 'bold'
  },
  tradeStatus: {
    alignItems: 'flex-end'
  },
  tradeTime: {
    fontSize: 12,
    color: '#757575'
  },
  tradeProfit: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 2
  },
  tradeDetails: {
    marginBottom: 16
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6
  },
  detailLabel: {
    fontSize: 12,
    color: '#757575'
  },
  detailValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#fff'
  },
  tradeActions: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  closeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F44336',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
    flex: 1,
    marginRight: 8,
    justifyContent: 'center'
  },
  infoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#333',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
    flex: 1,
    justifyContent: 'center'
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
    marginLeft: 6
  },
  historyTradeCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  resultBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20
  },
  resultText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold'
  },
  historyDetails: {
    marginBottom: 12
  },
  historyDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6
  },
  historyDetailLabel: {
    fontSize: 12,
    color: '#757575'
  },
  historyDetailValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#fff'
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60
  },
  emptyStateText: {
    fontSize: 16,
    color: '#757575',
    marginTop: 16,
    textAlign: 'center'
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#555',
    marginTop: 8,
    textAlign: 'center'
  }
});

export default TradesScreen;