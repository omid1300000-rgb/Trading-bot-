// صفحه داشبورد اصلی
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Dimensions
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import TradingService from '../services/TradingService';

const { width } = Dimensions.get('window');

const DashboardScreen = () => {
  const [tradingStats, setTradingStats] = useState(null);
  const [activeTrades, setActiveTrades] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [isAutoTrading, setIsAutoTrading] = useState(false);

  useEffect(() => {
    loadDashboardData();
    const interval = setInterval(() => {
      loadDashboardData();
    }, 5000); // به‌روزرسانی هر 5 ثانیه

    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    try {
      const stats = TradingService.getTradingStats();
      const trades = TradingService.getActiveTrades();
      
      setTradingStats(stats);
      setActiveTrades(trades);
      setIsAutoTrading(stats.autoTrading);
    } catch (error) {
      console.error('خطا در بارگذاری داده‌های داشبورد:', error);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const toggleAutoTrading = async () => {
    try {
      let result;
      if (isAutoTrading) {
        result = TradingService.stopAutoTrading();
      } else {
        result = await TradingService.startAutoTrading();
      }
      
      if (result.success) {
        setIsAutoTrading(!isAutoTrading);
        await loadDashboardData();
      }
    } catch (error) {
      console.error('خطا در تغییر حالت معاملات خودکار:', error);
    }
  };

  const formatCurrency = (value, currency = 'USD') => {
    return new Intl.NumberFormat('fa-IR', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const formatPercentage = (value) => {
    return `${value > 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  const getProfitColor = (profit) => {
    return profit > 0 ? '#4CAF50' : profit < 0 ? '#F44336' : '#757575';
  };

  const renderStatCard = (title, value, subtitle, color = '#4CAF50') => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <Text style={styles.statTitle}>{title}</Text>
      <Text style={styles.statValue}>{value}</Text>
      {subtitle && <Text style={styles.statSubtitle}>{subtitle}</Text>}
    </View>
  );

  const renderActiveTrade = (trade) => {
    const currentPrice = trade.entryPrice + (Math.random() - 0.5) * 0.01;
    const profit = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
    
    return (
      <View key={trade.id} style={styles.tradeCard}>
        <View style={styles.tradeHeader}>
          <View style={styles.tradeInfo}>
            <Text style={styles.tradeSymbol}>{trade.symbol}</Text>
            <Text style={[
              styles.tradeAction,
              { color: trade.action === 'buy' ? '#4CAF50' : '#F44336' }
            ]}>
              {trade.action === 'buy' ? 'خرید' : 'فروش'}
            </Text>
          </View>
          <Text style={[styles.tradeProfit, { color: getProfitColor(profit) }]}>
            {formatPercentage(profit)}
          </Text>
        </View>
        
        <View style={styles.tradeDetails}>
          <View style={styles.tradeDetail}>
            <Text style={styles.tradeDetailLabel}>قیمت ورود:</Text>
            <Text style={styles.tradeDetailValue}>
              {trade.entryPrice.toFixed(5)}
            </Text>
          </View>
          <View style={styles.tradeDetail}>
            <Text style={styles.tradeDetailLabel}>توقف ضرر:</Text>
            <Text style={styles.tradeDetailValue}>
              {trade.stopLoss.toFixed(5)}
            </Text>
          </View>
          <View style={styles.tradeDetail}>
            <Text style={styles.tradeDetailLabel}>برداشت سود:</Text>
            <Text style={styles.tradeDetailValue}>
              {trade.takeProfit.toFixed(5)}
            </Text>
          </View>
          <View style={styles.tradeDetail}>
            <Text style={styles.tradeDetailLabel}>اعتماد:</Text>
            <Text style={styles.tradeDetailValue}>
              {(trade.confidence * 100).toFixed(0)}%
            </Text>
          </View>
        </View>
        
        <TouchableOpacity 
          style={styles.closeTradeButton}
          onPress={() => {/* منطق بستن معامله */}}
        >
          <Icon name="close" size={20} color="#fff" />
          <Text style={styles.closeTradeText}>بستن</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl 
          refreshing={refreshing} 
          onRefresh={handleRefresh}
          colors={['#4CAF50']}
        />
      }
    >
      {/* هدر با کنترل معاملات خودکار */}
      <View style={styles.header}>
        <Text style={styles.title}>داشبورد معاملات</Text>
        <TouchableOpacity 
          style={[
            styles.autoTradingToggle,
            { backgroundColor: isAutoTrading ? '#4CAF50' : '#757575' }
          ]}
          onPress={toggleAutoTrading}
        >
          <Icon 
            name={isAutoTrading ? 'play-arrow' : 'pause'} 
            size={24} 
            color="#fff" 
          />
          <Text style={styles.autoTradingText}>
            {isAutoTrading ? 'متوقف کردن' : 'شروع خودکار'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* آمار کلی */}
      <View style={styles.statsContainer}>
        {renderStatCard(
          'معاملات کل',
          tradingStats?.totalTrades || 0,
          'تعداد کل معاملات',
          '#2196F3'
        )}
        {renderStatCard(
          'نرخ موفقیت',
          `${tradingStats?.winRate || 0}%`,
          'درصد معاملات موفق',
          '#FF9800'
        )}
        {renderStatCard(
          'معاملات فعال',
          tradingStats?.activeTrades || 0,
          'پوزیشن‌های باز',
          '#9C27B0'
        )}
        {renderStatCard(
          'حالت سیستم',
          isAutoTrading ? 'خودکار' : 'دستی',
          isAutoTrading ? 'در حال اسکن' : 'آماده',
          isAutoTrading ? '#4CAF50' : '#757575'
        )}
      </View>

      {/* معاملات فعال */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>معاملات فعال</Text>
          <Text style={styles.sectionSubtitle}>
            {activeTrades.length} پوزیشن باز
          </Text>
        </View>
        
        {activeTrades.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="trending-up" size={64} color="#757575" />
            <Text style={styles.emptyStateText}>
              هیچ معامله فعالی وجود ندارد
            </Text>
            <Text style={styles.emptyStateSubtext}>
              سیستم در حال جستجوی فرصت‌های معاملاتی است
            </Text>
          </View>
        ) : (
          activeTrades.map(renderActiveTrade)
        )}
      </View>

      {/* وضعیت اتصال */}
      <View style={styles.connectionStatus}>
        <View style={styles.connectionItem}>
          <Icon name="account-balance" size={20} color="#4CAF50" />
          <Text style={styles.connectionText}>
            صرافی: Binance متصل
          </Text>
        </View>
        <View style={styles.connectionItem}>
          <Icon name="psychology" size={20} color="#4CAF50" />
          <Text style={styles.connectionText}>
            AI: OpenAI GPT-4 متصل
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 16
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff'
  },
  autoTradingToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20
  },
  autoTradingText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 8
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20
  },
  statCard: {
    width: (width - 48) / 2,
    backgroundColor: '#1a1a1a',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderLeftWidth: 4
  },
  statTitle: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 4
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff'
  },
  statSubtitle: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4
  },
  section: {
    marginBottom: 20
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff'
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#757575'
  },
  tradeCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  tradeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  tradeInfo: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  tradeSymbol: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginLeft: 12
  },
  tradeAction: {
    fontSize: 14,
    fontWeight: 'bold'
  },
  tradeProfit: {
    fontSize: 16,
    fontWeight: 'bold'
  },
  tradeDetails: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 12
  },
  tradeDetail: {
    width: '48%',
    marginBottom: 8
  },
  tradeDetailLabel: {
    fontSize: 12,
    color: '#757575'
  },
  tradeDetailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 2
  },
  closeTradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F44336',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16
  },
  closeTradeText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 8
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40
  },
  emptyStateText: {
    fontSize: 16,
    color: '#757575',
    marginTop: 12,
    textAlign: 'center'
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#555',
    marginTop: 4,
    textAlign: 'center'
  },
  connectionStatus: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16
  },
  connectionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8
  },
  connectionText: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 12
  }
});

export default DashboardScreen;