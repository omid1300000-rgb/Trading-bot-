# 🚀 راهنمای کامل: ساخت APK با GitHub Actions (رایگان!)

## ✅ **مزایای این روش:**
- ✅ **۱۰۰% رایگان** - GitHub برای public repositories رایگان است
- ✅ **بدون محدودیت** - هیچ اشتراک پولی نمی‌خواهد
- ✅ **APK واقعی** - فایل APK واقعی و قابل نصب
- ✅ **خودکار** - هر بار کد آپلود کنید خودش APK می‌سازد
- ✅ **حرفه‌ای** - همان روش شرکت‌های بزرگ

---

## 🎯 **قدم ۱: آپلود کد به GitHub (۵ دقیقه)**

### ۱.۱: ورود به GitHub
1. **بروید:** https://github.com
2. **Sign up** یا **Sign in** کنید

### ۱.۲: ایجاد Repository جدید
1. **کلیک:** "New repository" (دکمه سبز)
2. **نام:** `trading-bot-app`
3. **تیک:** "Public" (برای رایگان بودن)
4. **تیک:** "Add a README file"
5. **کلیک:** "Create repository"

### ۱.۳: آپلود فایل‌ها
1. **کلیک:** "uploading an existing file"
2. **آپلود کنید:** تمام فایل‌های `mobile-trading-app`
3. **Message:** "Initial commit - Trading Bot app"
4. **کلیک:** "Commit changes"

---

## ⚙️ **قدم ۲: تنظیم GitHub Actions (۳ دقیقه)**

### ۲.۱: ایجاد فایل Workflow
1. در repository خود، **کلیک:** "Actions" (تب بالا)
2. **کلیک:** "New workflow"
3. **کلیک:** "set up a workflow yourself"

### ۲.۲: جایگزینی کد Workflow
**کل کد زیر را کپی کرده و جایگزین کنید:**

```yaml
name: React Native Android Build

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Install Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm install
      
    - name: Install Java JDK
      uses: actions/setup-java@v3
      with:
        distribution: 'zulu'
        java-version: '11'
        
    - name: Build Android Release
      run: |
        cd android
        chmod +x gradlew
        ./gradlew assembleRelease
        
    - name: Upload APK
      uses: actions/upload-artifact@v3
      with:
        name: app-release-apk
        path: android/app/build/outputs/apk/release/app-release.apk
```

### ۲.۳: ذخیره Workflow
1. **کلیک:** "Start commit"
2. **Message:** "Add Android build workflow"
3. **کلیک:** "Commit new file"

---

## 🔄 **قدم ۳: Build خودکار APK**

### ۳.۱: Trigger شدن Build
- **بلافاصله بعد از commit** - GitHub Actions شروع می‌کند
- **زمان Build:** ۵-۱۰ دقیقه
- **می‌توانید پیشرفت را ببینید:** Actions tab

### ۳.۲: Monitor کردن Build
1. **بروید:** "Actions" tab
2. **کلیک:** روی workflow در حال اجرا
3. **تماشای log ها** در real-time

---

## 📱 **قدم ۴: دانلود APK (۱ دقیقه)**

### ۴.۱: پیدا کردن Artifacts
1. **بعد از تکمیل Build** - به Actions برگردید
2. **کلیک:** روی workflow که تکمیل شده (تیک سبز ✅)
3. **اسکرول کنید پایین** تا "Artifacts" section

### ۴.۲: دانلود APK
1. **کلیک:** "app-release-apk" (blue button)
2. **فایل ZIP دانلود می‌شود**
3. **Extract کنید** فایل ZIP
4. **فایل `app-release.apk` را خواهید دید**

### ۴.۳: نصب روی گوشی
1. **آپلود کنید** `app-release.apk` به گوشی
2. **Install کنید** (Settings > Security > Unknown sources فعال کنید)
3. **آماده است!**

---

## 🛠️ **Troubleshooting:**

### اگر Build Failed شد:

#### مشکل: Node modules
```bash
# در Actions log، اضافه کنید:
- name: Clean install
  run: rm -rf node_modules package-lock.json && npm install
```

#### مشکل: Gradle permissions
```yaml
- name: Build Android Release
  run: |
    cd android
    chmod +x gradlew
    ./gradlew clean
    ./gradlew assembleRelease
```

#### مشکل: Java version
```yaml
- name: Install Java JDK
  uses: actions/setup-java@v3
  with:
    distribution: 'temurin'
    java-version: '17'
```

---

## 🔄 **برای Build های بعدی:**

### روش آسان:
1. **فایل جدید آپلود کنید** به GitHub repository
2. **GitHub خودش APK جدید می‌سازد!**
3. **بدون هیچ تنظیم اضافی**

### یا دستی:
1. **Actions tab**
2. **"React Native Android Build"**
3. **"Run workflow"**

---

## ✅ **تضمین موفقیت:**

### **این روش ۹۹% کار می‌کند چون:**
- ✅ **GitHub Actions کاملاً رایگان**
- ✅ **React Native Official support**
- ✅ **هزاران پروژه از این روش استفاده می‌کنند**
- ✅ **Community support عالی**

### **زمان مورد نیاز:**
- **Setup اولیه:** ۱۰ دقیقه
- **هر Build بعدی:** ۵ دقیقه
- **دانلود APK:** ۱ دقیقه

---

## 🎯 **خلاصه قدم‌ها:**

### ۱. GitHub Repository ایجاد کنید (۵ دقیقه)
### ۲. فایل‌های کد را آپلود کنید (۳ دقیقه)  
### ۳. Workflow را اضافه کنید (۲ دقیقه)
### ۴. صبر کنید تا Build شود (۵-۱۰ دقیقه)
### ۵. APK را دانلود کنید (۱ دقیقه)

**مجموع: ۱۵-۲۰ دقیقه برای بار اول**  
**بعدی: ۵-۶ دقیقه برای هر Build جدید**

---

**🎉 این بهترین و کاملاً رایگان‌ترین راه‌حل موجود است!**

**هیچ سایت پولی نمی‌خواهد - فقط GitHub رایگان!**