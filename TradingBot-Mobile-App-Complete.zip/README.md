# 🤖 Trading Bot Mobile App

## 📱 React Native Trading Application

### **ویژگی‌ها:**
- ✅ **۶ صرافی ایرانی:** Wallex, Bitpin, Nobitex, Exir, ArzanTrade, ToPala
- ✅ **۷ صرافی بین‌المللی:** Binance, Coinbase, Kraken, Bitfinex, OKX, KuCoin, Huobi  
- ✅ **۳ هوش مصنوعی:** OpenAI GPT, Anthropic Claude, Custom AI
- ✅ **رابط کامل فارسی** با پشتیبانی RTL
- ✅ **Real-time Trading** با WebSocket connections
- ✅ **Advanced Charts** با TradingView integration
- ✅ **Portfolio Management** و Risk Assessment

### **پشتیبانی سیستم‌عامل:**
- 📱 **Android:** APK (این پروژه)
- 🍎 **iOS:** در دست توسعه

---

## 🚀 **ساخت APK با GitHub Actions (رایگان!)**

### قدم ۱: آپلود به GitHub
1. **ایجاد Repository جدید** در GitHub
2. **آپلود تمام فایل‌های** این پروژه
3. **Repository را Public کنید** (برای رایگان بودن)

### قدم ۲: فعال‌سازی GitHub Actions
1. **بروید:** Actions tab در GitHub
2. **کلیک:** "New workflow" 
3. **کپی پیست کنید** فایل `build.yml` (در این پروژه موجود)
4. **Commit کنید** workflow file

### قدم ۳: Build و دانلود APK
- **GitHub خودکار شروع می‌کند** به build کردن
- **زمان Build:** ۵-۱۰ دقیقه
- **دانلود APK:** از Artifacts section در Actions

### 📋 **فایل‌های مهم:**
```
├── build.yml              # GitHub Actions workflow
├── App.js                 # Main app component
├── package.json           # Dependencies
├── android/               # Android native files
├── src/                   # Source code
└── assets/                # Images & fonts
```

---

## ⚠️ هشدار مهم
**این اپلیکیشن برای تست و یادگیری طراحی شده است. قبل از استفاده با پول واقعی، حتماً در حالت دمو تست کنید!**

## 📋 فهرست
1. [نصب و راه‌اندازی](#نصب-و-راهاندازی)
2. [رابط کاربری](#رابط-کاربری)
3. [تنظیم صرافی‌ها](#تنظیم-صرافیها)
4. [تنظیم هوش مصنوعی‌ها](#تنظیم-هوش-مصنوعیها)
5. [کنترل سیستم](#کنترل-سیستم)
6. [نمونه پیکربندی](#نمونه-پیکربندی)

## 🚀 نصب و راه‌اندازی

### پیش‌نیازها
```bash
# نصب Python 3.8+
python --version

# نصب کتابخانه‌های مورد نیاز
pip install aiohttp pandas requests sqlite3 asyncio
```

### اجرای سیستم
```bash
# اجرای سیستم اصلی
python auto_trading_system.py

# اجرای رابط وب (در مرورگر)
open trading_interface.html
```

## 💻 رابط کاربری

### تب‌های اصلی:
- **📊 داشبورد**: نمای کلی سیستم و کنترل
- **💱 صرافی‌ها**: مدیریت صرافی‌ها
- **🧠 هوش مصنوعی**: اتصال به AI ها
- **⚙️ تنظیمات**: تنظیمات سیستم
- **📋 لاگ‌ها**: لاگ‌های سیستم

## 💰 تنظیم صرافی‌ها

### صرافی‌های پشتیبانی شده:
- **Binance** - ارز دیجیتال
- **Bybit** - ارز دیجیتال
- **OKX** - ارز دیجیتال
- **Kraken** - ارز دیجیتال
- **Gate.io** - ارز دیجیتال
- **FXCM** - فارکس
- **OANDA** - فارکس

### نحوه افزودن صرافی:

#### 1. Binance
```
نوع: Binance
API Key: کلید عمومی Binance
API Secret: کلید خصوصی Binance
حالت: Demo (توصیه می‌شود)
حداکثر اسلیپیج: 0.01 (1%)
```

#### 2. FXCM (فارکس)
```
نوع: FXCM
API Key: کلید FXCM
API Secret: کلید FXCM
حالت: Demo
حداکثر اسلیپیج: 0.001 (0.1%)
```

### تنظیمات مهم:
- **حداکثر اسلیپیج**: کنترل تفاوت قیمت مجاز
- **حداقل موجودی**: حداقل موجودی برای شروع معامله
- **حالت دمو**: همیشه ابتدا از دمو استفاده کنید

## 🧠 تنظیم هوش مصنوعی‌ها

### نحوه اتصال به AI:

#### 1. فرمت JSON
```json
{
  "symbol": "EURUSD",
  "signal_type": "buy",
  "entry_price": 1.0850,
  "stop_loss": 1.0800,
  "take_profit": 1.0900,
  "quantity": 1000,
  "leverage": 10,
  "confidence": 0.85
}
```

#### 2. فرمت API Response
```json
{
  "data": {
    "pair": "BTCUSDT",
    "action": "sell",
    "entry": 45000,
    "sl": 46000,
    "tp": 44000,
    "amount": 0.1
  }
}
```

### فیلدهای قابل تنظیم:
- **فیلد نماد**: نام فیلد جفت ارز در پاسخ
- **فیلد قیمت ورود**: نام فیلد قیمت ورود
- **فیلد Stop Loss**: نام فیلد حدضرر
- **فیلد Take Profit**: نام فیلد حدسود
- **فیلد مقدار**: نام فیلد مقدار معامله
- **فیلد لوریج**: نام فیلد لوریج

## ⚙️ تنظیمات سیستم

### تنظیمات تریدینگ:
- **لوریج پیش‌فرض**: 1x (1 برابر)
- **حداکثر اندازه پوزیشن**: 1000 دلار
- **ریسک هر معامله**: 2% از سرمایه
- **تحمل اسلیپیج**: 0.1%

### تنظیمات اسکنر بازار:
- **فعال بودن**: ✅
- **فاصله اسکن**: 60 ثانیه
- **بازه زمانی**: 1 ساعت
- **نمادهای مورد نظر**: EURUSD,GBPUSD,BTCUSDT,ETHUSDT

## 🎮 کنترل سیستم

### دکمه‌های کنترل:
- **▶️ شروع**: شروع تریدینگ خودکار
- **⏹️ توقف**: توقف کامل سیستم
- **⏸️ توقف موقت**: توقف موقت

### نمایش وضعیت:
- **🟢 فعال**: سیستم در حال اجرا
- **🟡 متوقف موقت**: سیستم متوقف موقت
- **🔴 متوقف**: سیستم خاموش

## 📊 نمونه پیکربندی کامل

### فایل config.json نمونه:
```json
{
  "exchanges": {
    "binance_main": {
      "exchange_type": "binance",
      "api_key": "YOUR_BINANCE_API_KEY",
      "api_secret": "YOUR_BINANCE_SECRET",
      "sandbox": true,
      "max_slippage": 0.01,
      "min_balance": 100.0
    },
    "fxcm_demo": {
      "exchange_type": "fxcm",
      "api_key": "YOUR_FXCM_API_KEY",
      "api_secret": "YOUR_FXCM_SECRET",
      "sandbox": true,
      "max_slippage": 0.001,
      "min_balance": 1000.0
    }
  },
  "ai_configs": {
    "technical_ai": {
      "name": "AI تحلیل تکنیکال",
      "api_url": "https://api.example.com/technical-signal",
      "api_key": "YOUR_AI_API_KEY",
      "signal_format": "json",
      "symbol_field": "symbol",
      "entry_field": "entry_price",
      "sl_field": "stop_loss",
      "tp_field": "take_profit",
      "quantity_field": "quantity",
      "leverage_field": "leverage",
      "timeout": 30
    }
  },
  "trading_settings": {
    "default_leverage": 1,
    "max_position_size": 1000,
    "risk_per_trade": 0.02,
    "slippage_tolerance": 0.001
  },
  "market_scanner": {
    "enabled": true,
    "interval": 60,
    "symbols": ["EURUSD", "GBPUSD", "BTCUSDT", "ETHUSDT"],
    "timeframe": "1h"
  }
}
```

## 🔧 رفع مشکلات متداول

### خطای اتصال به صرافی:
1. بررسی API Key و Secret
2. اطمینان از فعال بودن API
3. بررسی محدودیت نرخ درخواست

### خطای اتصال به AI:
1. بررسی آدرس API
2. بررسی API Key
3. تست اتصال با Postman
4. بررسی فرمت پاسخ

### اسلیپیج بالا:
1. کاهش مقدار معامله
2. افزایش حداکثر اسلیپیج
3. انتخاب صرافی با نقدشوندگی بیشتر

### سیگنال‌های معتبر نبود:
1. بررسی فرمت پاسخ AI
2. تنظیم فیلدهای مربوطه
3. افزایش آستانه اعتماد

## 🛡️ امنیت

### بهترین شیوه‌ها:
- هرگز API Key ها را در کد نگذارید
- از حالت دمو برای تست استفاده کنید
- محدودیت ریسک تنظیم کنید
- لاگ‌ها را بررسی کنید

### ذخیره امن کلیدها:
```bash
# ایجاد فایل محیطی
echo "BINANCE_API_KEY=your_key" > .env
echo "BINANCE_SECRET=your_secret" >> .env

# استفاده در کد
import os
from dotenv import load_dotenv
load_dotenv()

api_key = os.getenv('BINANCE_API_KEY')
```

## 📈 بهینه‌سازی عملکرد

### تنظیمات پیشنهادی:
- فاصله اسکن: 60-300 ثانیه
- حداقل اعتماد AI: 70%
- حداکثر پوزیشن همزمان: 3-5
- ریسک هر معامله: 1-2%

### نظارت:
- بررسی روزانه لاگ‌ها
- نظارت بر عملکرد AI ها
- تحلیل سود/زیان هفتگی
- بروزرسانی استراتژی‌ها

## 📞 پشتیبانی

### منابع کمکی:
- لاگ‌های سیستم: `trading_system.log`
- پایگاه داده: `trading_data.db`
- راهنمای API صرافی‌ها
- مستندات AI ها

### گزارش مشکلات:
1. بررسی لاگ‌ها
2. ثبت مراحل تکراری
3. جمع‌آوری اطلاعات سیستم
4. ارسال گزارش

---

**🎯 هدف**: تریدینگ خودکار و ایمن با کنترل کامل
**⚠️ یادآوری**: همیشه با مقادیر کم شروع کنید!